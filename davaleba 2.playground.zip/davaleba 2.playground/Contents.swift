class Company{
    var name : String
    var year : Int
    var headoffice: String
    var founder : String
    
    init(name:String,year:Int,headoffice:String,founder:String) {
        self.name=name
        self.year=year
        self.headoffice=headoffice
        self.founder=founder
    }
    func about() -> String {
        let a="my namy is \(name)i based in \(year) by \(founder)"
        return(a)
    }
}
class Apple: Company {
    let owns=["ios","iphone"]
}

class Google : Company{
    
}
class Facebook: Company {
    
}
var a = Apple(name: "Apple", year: 1991, headoffice: "New Jersey", founder: "steve jobs")
var b = Google(name: "das", year: 1992, headoffice: "dubai", founder: "dfsadsa")
print(a.about())
print(b.about())
print(a.owns)
