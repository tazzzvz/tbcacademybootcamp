//დაწერეთ ფუნქცია რომელიც პარამეტრად მიიღებს ორი მთელი რიცხვების მასივს და დააბრუნებს მათ თანაკვეთას


func array(inputarray: Array<Int>,inputarray2:Array<Int>) -> Array<Int>{
    var answer=[Int]()
    for i in inputarray{
        for j in inputarray2{i
            if i == j{
                answer.append(i)
            }
            
        }
    }
    print(answer)
    return answer
}
array(inputarray: [1,2,3,7,5432,43], inputarray2: [1,5,6,7,3])

//დაწერეთ ფუნქცია რომელიც პარამეტრად მიიღებს ორი მთელი რიცხვების მასივს და დააბრუნებს მათ გაერთიანებას


func gaertianeba(inputarray: Array<Int>,inputarray2:Array<Int>) -> Array<Int>{
    var newarray=[Int]()
    for i in inputarray{
        newarray.append(i)
        
        
    }
    for i in inputarray2 {
    
        newarray.append(i)
    }
    
    return newarray

}
print(gaertianeba(inputarray: [1,2,3,4,5,6,7], inputarray2:   [76,54,23,2,3]))


//დაწერეთ ფუნქცია რომელიც პარამეტრად მიიღებს მთელი რიცხვების მასივს და დააბრუნებს რამდენი განსხვავებული ელემენტია მასში.(სორტირების გამოყენების გარეშე)


func Count(inputarray: Array<Int>) -> Int{
    
    var answer=0
 
    for i in inputarray{
        var count=0
        for j in inputarray{
            
            if i==j{
                count=count+1
            }
            
            if count==2{
                answer=answer+1
            }
        }
    }
    
    return inputarray.count-answer+1
    
}
print(Count(inputarray: [1,2,3,4,4,4,5,6,45,65,43,12]))

